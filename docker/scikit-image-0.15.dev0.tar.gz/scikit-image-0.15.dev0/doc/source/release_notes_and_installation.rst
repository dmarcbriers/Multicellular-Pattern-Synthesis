.. |nbsp| unicode:: 0xA0
   :trim:

.. contents:: |nbsp|

Release notes
=============

.. include:: ../release/_release_notes_for_docs.rst

Installation
============

.. include:: install.rst
