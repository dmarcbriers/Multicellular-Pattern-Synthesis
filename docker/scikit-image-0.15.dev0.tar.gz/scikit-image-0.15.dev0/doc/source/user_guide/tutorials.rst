Tutorials
=========

.. toctree::
   :maxdepth: 1

   tutorial_segmentation
   tutorial_parallelization
