Segmentation of objects
-----------------------
